import os
from pathlib import Path
import csv

image_path = Path(__file__).parent / "image_folder"
csv_file = Path(__file__).parent / "datatest.csv"

with open(csv_file, mode="r") as csvfile:
    csvfileread = csv.reader(csvfile)
    for lines in csvfileread:
        print(lines)

font = []
size = []
colour = []

for image_path in image_path.iterdir():
    print(str(image_path))